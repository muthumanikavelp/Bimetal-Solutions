﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BiMetal_Api.Models
{
    public class SQLData
    {       
        [DataMember]
        public string sqlquery { get; set; }
    }
}