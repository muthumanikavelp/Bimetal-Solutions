﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using BiMetal_Api.Models;
using System.Data;
using System.Configuration;
using System.IO;
using BusinessEntity;

namespace BiMetal_Api.Controllers
{
    public class SQLDataController : ApiController
    {
        log4net.ILog logger4net = log4net.LogManager.GetLogger(typeof(SQLDataController));
        SQLData_BS Objdata_BL = new SQLData_BS();

        [System.Web.Mvc.Route("GETQUERY")]
        [HttpPost]
        public DataTable GetQueryDetails([FromBody] SQLData  Query)
        {
            
            DataTable dt=new DataTable ();
            try
            {

                string[] condition =
                {
                   
                    "DELETE",
                    "INSERT",
                    "EXEC "
                };

                string condition_set = "TRUE";
                string Queryset = Query.sqlquery.ToUpper();

                foreach (string c in condition)
                {

                    if (Queryset.Contains(c))
                    {

                        condition_set = "FALSE";

                        dt.Columns.Add("ERROR", typeof(string));
                        dt.Rows.Add("QUERY ERROR");
                    }

                }

                if (condition_set == "TRUE")
                {
                    dt = Objdata_BL.GetTableDt(Query);
                }


            }
            catch (Exception ex)
            {
                logger4net.Error(ex.ToString());
            }
            return dt;
        }
    }
}
