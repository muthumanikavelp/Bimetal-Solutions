﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DataModel;
using BiMetal_Api.Models;


namespace BusinessEntity
{
    public class SQLData_BS
    {
        public DataTable GetTableDt(SQLData Query)
        {

            DataTable dt = new DataTable();
            try
            {
                DataConnection objData = new DataConnection();
                dt = objData.GetTable(Query);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
    }
}
