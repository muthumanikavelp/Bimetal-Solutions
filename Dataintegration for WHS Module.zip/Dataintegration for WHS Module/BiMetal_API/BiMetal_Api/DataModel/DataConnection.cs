﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Net;
using System.Web;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Configuration;
using BiMetal_Api.Models;
using BusinessEntity;


namespace DataModel
{
   public  class DataConnection
    {
       log4net.ILog logger4net = log4net.LogManager.GetLogger(typeof(DataConnection));
        private SqlDataAdapter da;
        private SqlConnection con;
        private SqlDataReader dr;
        private SqlCommand cmd;

        public DataConnection()
        {
            //con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"].ToString());
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ToString());
            //dr = null;
            cmd = new SqlCommand();
            cmd.Connection = con;
            //table=new DataTable();
        }

        public DataTable GetTable(SQLData command)
        {
            cmd.CommandText = command.sqlquery;
            DataTable table = new DataTable();
            try
            {
                con.Open();
                da = new SqlDataAdapter(cmd);
                da.Fill(table);
                con.Close();
            }
            catch (Exception ex)
            {
                logger4net.Error(ex.ToString());
            }
            finally
            {
                con.Close();
            }
            return table;
        }



    }
}
