﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Net;
using System.Web;
using System.Net.Mail;
using System.Data.SqlClient;

namespace Bimetal_Win
{
 public   class GlobalODBC
    {
        private MySqlDataAdapter da;
        private MySqlConnection con;
        private MySqlDataReader dr;
        private MySqlCommand cmd;

        public GlobalODBC()
        {
            //con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"].ToString());
            con = new MySqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ToString());
            //dr = null;
            cmd = new MySqlCommand();
            cmd.Connection = con;
            //table=new DataTable();
        }
        public string ExecuteScal(string command)
        {

            cmd.CommandText = command;
            con.Open();

            try
            {
                object StrVal = cmd.ExecuteScalar();
                con.Close();
                return StrVal.ToString();
            }
            catch (Exception ex)
            {
                con.Close();
                return "";

            }
        }

     public string ExecuteNonQuery(string command)
        {
            cmd.CommandText = command;
            con.Open();

            try
            {
                object StrVal = cmd.ExecuteNonQuery();
                con.Close();
                return StrVal.ToString();
            }
            catch (Exception ex)
            {
                con.Close();
                return "";

            }
        }

        public DataTable RunProc(string command, Dictionary<string, Object> values = null)
        {
            DataTable temp = new DataTable();
            cmd.CommandText = command;
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                //Dim parmReturnValue As SqlParameter SS
                if (values != null)
                {
                    foreach (string key in values.Keys)
                    {

                        cmd.Parameters.AddWithValue(key, values[key]);


                    }
                }

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(temp);
                return temp;
            }
            catch (Exception ex)
            {
                return temp;

            }

        }

        //Insert Distributor  Details
        public DataTable InsertDistributorDetails(WinBO ObjDis_dt)
        {
            //log4net.ILog logger = log4net.LogManager.GetLogger(typeof(GlobalODBC ));
            int rows = 0;
            DataTable table = new DataTable();
            try
            {
                GlobalODBC connection = new GlobalODBC();
                Dictionary<string, Object> values = new Dictionary<string, object>();
                values.Add("p_Customercode", ObjDis_dt.CUSTOMERCODE );
                values.Add("p_Customername", ObjDis_dt.CUSTOMERNAME );
                values.Add("p_Country", ObjDis_dt.COUNTRY);
                values.Add("p_State", ObjDis_dt.CSTATE);
                values.Add("p_City", ObjDis_dt.CITY);
                values.Add("p_Pincode", ObjDis_dt.PINCODE);
                values.Add("p_Contactperson", ObjDis_dt.CONTACTPERSON);
                values.Add("p_Mobileno", ObjDis_dt.MOBILENO);
                values.Add("p_Email", ObjDis_dt.EMAIL);
                values.Add("p_Address", ObjDis_dt.CADDRESS);
                values.Add("p_Gstno", ObjDis_dt.GSTNO);
                values.Add("p_Location", ObjDis_dt.LOCATION);
                values.Add("p_Recid", ObjDis_dt.RECID);
                values.Add("p_transport", ObjDis_dt.TRANSPORT);
                table = connection.RunProc("InsertDistributorDetails_Win", values);
                return table;
            }
            catch (Exception ex)
            {
                //logger.Error(ex.ToString());
                return table;
            }
        }
     //Insert Product List
        public DataTable InsertProductDetails(WinBO ObjProd_dt)
        {
            //log4net.ILog logger = log4net.LogManager.GetLogger(typeof(GlobalODBC ));
            int rows = 0;
            DataTable table = new DataTable();
            try
            {
                GlobalODBC connection = new GlobalODBC();
                Dictionary<string, Object> values = new Dictionary<string, object>();
                values.Add("p_ITEMCODE", ObjProd_dt.ITEMCODE );
                values.Add("p_ITEMGROUP", ObjProd_dt.ITEMGROUP );
                values.Add("p_PRODUCTDESC", ObjProd_dt.PRODUCTDESC );
                values.Add("p_MRP", ObjProd_dt.MRP );
                values.Add("p_RECID", ObjProd_dt.RECID );
                values.Add("p_MODELNO", ObjProd_dt.MODELNO );
                values.Add("p_Size", ObjProd_dt.SIZE );
                values.Add("p_PIECES", ObjProd_dt.PIECES );
                values.Add("p_LISTPRICE", ObjProd_dt.LISTPRICE );
                values.Add("p_enginetype", ObjProd_dt.EngineType);
                values.Add("p_incenamnt", ObjProd_dt.INCENAMNT);
                values.Add("p_partno", ObjProd_dt.PART_NO);
                table = connection.RunProc("InsertProductDetails_Win", values);
                return table;
            }
            catch (Exception ex)
            {
                //logger.Error(ex.ToString());
                return table;
            }
        }

        //Insert Packing List
        public DataTable InsertPackingDetails(WinBO ObjPack_dt)
        {
            //log4net.ILog logger = log4net.LogManager.GetLogger(typeof(GlobalODBC ));
            int rows = 0;
            DataTable table = new DataTable();
            try
            {
                GlobalODBC connection = new GlobalODBC();
                Dictionary<string, Object> values = new Dictionary<string, object>();
                values.Add("p_sn", ObjPack_dt.SN);
                values.Add("p_Invoicedate", ObjPack_dt.INVOICEDATE);
                values.Add("p_DistributorCode", ObjPack_dt.DISTRIBUTOR_CODE);
                values.Add("p_ItemCode", ObjPack_dt.ITEMCODE);
                values.Add("p_Qty", ObjPack_dt.QTY);
                values.Add("p_BoxNo", ObjPack_dt.BOXNO);
                values.Add("p_Transport", ObjPack_dt.TRANSPORT);
                values.Add("p_Mk", ObjPack_dt.MK);
                values.Add("p_Oeno", ObjPack_dt.OENO);
                values.Add("p_Location", ObjPack_dt.LOCATION);
                table = connection.RunProc("InsertPackingDetails_Win", values);
                return table;
            }
            catch (Exception ex)
            {
                //logger.Error(ex.ToString());
                return table;
            }
        }

     //Insert Invoice List
     public DataTable InsertInvoiceDetails(WinBO ObjInvoice_dt)
        {
            int rows = 0;
            DataTable table = new DataTable();
            try
            {
                GlobalODBC connection = new GlobalODBC();
                Dictionary<string, Object> values = new Dictionary<string, object>();
                values.Add("p_Salesid", ObjInvoice_dt.SALESID);
                values.Add("p_Itemcode", ObjInvoice_dt.ITEMCODE);
                values.Add("p_Sn", ObjInvoice_dt.SN);
                values.Add("p_InvoiceDate", ObjInvoice_dt.INVOICEDATE);
                values.Add("p_Qty", ObjInvoice_dt.QTY);
                values.Add("p_Srt", ObjInvoice_dt.SRT);
                values.Add("p_SVAL", ObjInvoice_dt.SVAL);
                values.Add("p_IGSTPER", ObjInvoice_dt.IGSTPER);
                values.Add("p_IGSTAMOUNT", ObjInvoice_dt.IGSTAMOUNT);
                values.Add("p_CGSTPER", ObjInvoice_dt.CGSTPER);
                values.Add("p_CGSTAMOUNT", ObjInvoice_dt.CGSTAMOUNT);
                values.Add("p_SGSTPER", ObjInvoice_dt.SGSTPER);
                values.Add("p_SGSTAMOUNT", ObjInvoice_dt.SGSTAMOUNT);
                values.Add("p_CUSID", ObjInvoice_dt.CUSID);
                values.Add("p_DEST", ObjInvoice_dt.DEST);
                values.Add("p_CSTATE", ObjInvoice_dt.CSTATE);
                values.Add("p_LRNO", ObjInvoice_dt.LRNO);
                values.Add("p_LRDATE", ObjInvoice_dt.LRDATE);
                values.Add("p_SITEID", ObjInvoice_dt.SITEID);
                values.Add("p_RECID", ObjInvoice_dt.RECID);

                table = connection.RunProc("InsertInvoiceDetails_Win", values);
                return table;
            }
            catch (Exception ex)
            {
                //logger.Error(ex.ToString());
                return table;
            }
        }



    
    }
}
