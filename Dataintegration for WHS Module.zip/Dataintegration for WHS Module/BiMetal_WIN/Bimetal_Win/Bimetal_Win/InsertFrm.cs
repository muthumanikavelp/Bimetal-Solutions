﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net.Http;


namespace Bimetal_Win
{
    public partial class InsertFrm : Form
    {


        public InsertFrm()
        {
            InitializeComponent();
        }
        private void InsetFrm_Load (object sender, EventArgs e)
        {
            //EmpInsertStatement();

            AutoTransaction();
            DisbutorInsertStatement();
           // ProductInsertStatement();
            //PackingInsertStatement();
            //InvoiceInsertStatement();

            //this.Close();

        }
        //private async void EmpInsertStatement()
        //{
        //    try
        //    {
        //        EmployeeDetails ObjEmp_dt = new EmployeeDetails();
        //        ObjEmp_dt.sqlquery = "select * from TBL_EMPLOYEE";
        //        string url = "http://182.72.217.90/GNSA/GETQUERY";
        //        using (var client = new HttpClient())
        //        {
        //            string json = JsonConvert.SerializeObject(ObjEmp_dt);
        //            var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
        //            var data = result.Content.ReadAsStringAsync();
        //            string Employeedts = Convert.ToString(data.Result.ToString().Trim());
        //            var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
        //            DataSet ds = new DataSet();
        //            ds.Clear();
        //            ds.Tables.Add(dt);
        //            if (dt.Rows.Count > 0)
        //            {
        //                for (int i = 0; i < dt.Columns.Count; i++)
        //                {
        //                    ObjEmp_dt.Employee_Code = dt.Rows[i][0].ToString();
        //                    ObjEmp_dt.Employee_name = dt.Rows[i][1].ToString();
        //                    ObjEmp_dt.Deapartment_Id = dt.Rows[i][2].ToString();
        //                    ObjEmp_dt.Location = dt.Rows[i][3].ToString();
        //                    ObjEmp_dt.BoxNo = dt.Rows[i][4].ToString();
        //                    ObjEmp_dt.CAddress = dt.Rows[i][5].ToString();
        //                    ObjEmp_dt.Country = dt.Rows[i][6].ToString();
        //                    ObjEmp_dt.CState = dt.Rows[i][7].ToString();
        //                    ObjEmp_dt.City = dt.Rows[i][8].ToString();

        //                    ObjEmp_dt.Grade = dt.Rows[i][3].ToString();

        //                    GlobalODBC GlbCmd = new GlobalODBC();
        //                }

        //            }


        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }

        //}

        private void AutoTransaction()
        {
            try
            {

                WinBO ObjDis_dt = new WinBO();

                string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                  "VALUES (now(),'Start Process')";

             string InsertQuery = WinBL.ExecuteNonq(sqlquery);
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void DisbutorInsertStatement()
        {
            try
            {
                WinBO ObjDis_dt = new WinBO();

               ObjDis_dt.sqlquery = "select * from TBL_DISTRIBUTOR where Flag is null or flag='N'";
               // ObjDis_dt.sqlquery = "select * from TBL_DISTRIBUTOR";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjDis_dt);
                    //client.Timeout = TimeSpan.FromMilliseconds(5000);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                 
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            ObjDis_dt.CUSTOMERCODE = dt.Rows[i]["CUSTOMERCODE"].ToString();
                            ObjDis_dt.CUSTOMERNAME = dt.Rows[i]["CUSTOMERNAME"].ToString();
                            ObjDis_dt.COUNTRY = dt.Rows[i]["COUNTRY"].ToString();
                            ObjDis_dt.CSTATE = dt.Rows[i]["CSTATE"].ToString();
                            ObjDis_dt.CITY = dt.Rows[i]["CITY"].ToString();
                            ObjDis_dt.PINCODE = dt.Rows[i]["PINCODE"].ToString();
                            ObjDis_dt.CONTACTPERSON = dt.Rows[i]["CONTACTPERSON"].ToString();
                            ObjDis_dt.MOBILENO = dt.Rows[i]["MOBILENO"].ToString();
                            ObjDis_dt.EMAIL = dt.Rows[i]["EMAIL"].ToString();
                            ObjDis_dt.CADDRESS = dt.Rows[i]["CADDRESS"].ToString();
                            ObjDis_dt.GSTNO = dt.Rows[i]["GSTNO"].ToString();
                            ObjDis_dt.LOCATION = dt.Rows[i]["LOCATION"].ToString();
                            ObjDis_dt.RECID = Convert.ToInt64(dt.Rows[i]["RECID"].ToString());
                            ObjDis_dt.TRANSPORT = dt.Rows[i]["TRANSPORT"].ToString();

                            DataTable Distributorindx = new DataTable();
                            Distributorindx = WinBL.insertDistributordt(ObjDis_dt);

                            
                        }

                        string Distributor = "Insert Distributor " + "_" + dt.Rows.Count;
                        string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                          "VALUES (now(),'" + Distributor +"' )";
                        string InsertQuery = WinBL.ExecuteNonq(sqlquery);
                    }
                    UpdateDistributorDetails();
                    
                
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void UpdateDistributorDetails()
        {
            try
            {
                WinBO ObjDis_dt = new WinBO();
                ObjDis_dt.sqlquery = "update TBL_DISTRIBUTOR set flag='Y' where flag is null or flag='N' ";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjDis_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {
                       
                    }
                    ProductInsertStatement();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private async void ProductInsertStatement()
        {
            try
            {
                WinBO ObjPrd_dt = new WinBO();
                 ObjPrd_dt.sqlquery = "select * from TBL_PRODUCTS where flag is null or flag='N'";
                //ObjPrd_dt.sqlquery = "select * from TBL_PRODUCTS";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjPrd_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            ObjPrd_dt.ITEMCODE = dt.Rows[i]["ITEMCODE"].ToString();
                            ObjPrd_dt.ITEMGROUP = dt.Rows[i]["ITEMGROUP"].ToString();
                            ObjPrd_dt.PRODUCTDESC = dt.Rows[i]["PRODUCTDESC"].ToString();
                            ObjPrd_dt.MRP = dt.Rows[i]["MRP"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["MRP"].ToString()) : 0.00;
                            ObjPrd_dt.RECID = Convert.ToInt64(dt.Rows[i]["RECID"].ToString());
                            ObjPrd_dt.MODELNO = dt.Rows[i]["MODELNO"].ToString();
                            ObjPrd_dt.SIZE = dt.Rows[i]["SIZE"].ToString();
                            ObjPrd_dt.PIECES = dt.Rows[i]["PIECES"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["PIECES"].ToString()) : 0.00;
                            ObjPrd_dt.LISTPRICE = dt.Rows[i]["LISTPRICE"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["LISTPRICE"].ToString()) : 0.00;
                            ObjPrd_dt.EngineType = dt.Rows[i]["ENGINE_TYPE"].ToString();
                            ObjPrd_dt.INCENAMNT = dt.Rows[i]["INCENAMNT"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["INCENAMNT"].ToString()) : 0.00;
                            ObjPrd_dt.PART_NO = dt.Rows[i]["PART_NO"].ToString();
                            DataTable ProductdtIndx = new DataTable();

                            ProductdtIndx = WinBL.insertProductdt(ObjPrd_dt);                            
                        }

                        string Product = "Insert Productdetails " + "_" + dt.Rows.Count;
                        string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                          "VALUES (now(),'" + Product + "' )";
                        string InsertQuery = WinBL.ExecuteNonq(sqlquery);
                    }
                    UpdateproductStatement();
                  
                  
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void UpdateproductStatement()
        {
            try
            {
                WinBO ObjDis_dt = new WinBO();
                ObjDis_dt.sqlquery = "update TBL_PRODUCTS set flag='Y' where flag is null or flag='N'";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjDis_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {

                    }
                    PackingInsertStatement();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private async void PackingInsertStatement()
        {
            try
            {
                WinBO ObjPack_dt = new WinBO();
                ObjPack_dt.sqlquery = "select * from TBL_PACKINGSLIP where flag is null or flag='N'";
               // ObjPack_dt.sqlquery = "select * from TBL_PACKINGSLIP";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjPack_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows .Count; i++)
                        {
                            ObjPack_dt.SN = dt.Rows[i]["SN"].ToString();
                            ObjPack_dt.INVOICEDATE = Convert.ToDateTime (dt.Rows[i]["INVOICEDATE"].ToString());
                            ObjPack_dt.DISTRIBUTOR_CODE = dt.Rows[i]["DISTRIBUTOR_CODE"].ToString();
                            ObjPack_dt.ITEMCODE = dt.Rows[i]["ITEMCODE"].ToString();
                            ObjPack_dt.QTY = dt.Rows[i]["QTY"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["QTY"].ToString()) : 0.00;
                            ObjPack_dt.BOXNO = dt.Rows[i]["BOXNO"].ToString();
                            ObjPack_dt.TRANSPORT = dt.Rows[i]["TRANSPORT"].ToString();
                            ObjPack_dt.MK = dt.Rows[i]["MK"].ToString();
                            ObjPack_dt.OENO = dt.Rows[i]["OENO"].ToString();
                            ObjPack_dt.LOCATION = dt.Rows[i]["LOCATION"].ToString();

                            DataTable PackingIndx = new DataTable();
                            PackingIndx = WinBL.insertPackingdt(ObjPack_dt);
                        }

                        string Packing = "Insert Packingdetails " + "_" + dt.Rows.Count;
                        string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                          "VALUES (now(),'" + Packing + "' )";
                        string InsertQuery = WinBL.ExecuteNonq(sqlquery);
                    }
                    UpdatePackingStatement();
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void UpdatePackingStatement()
        {
            try
            {
                WinBO ObjDis_dt = new WinBO();
                ObjDis_dt.sqlquery = "update TBL_PACKINGSLIP set flag='Y' where flag is null or flag='N'";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjDis_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {

                    }
                    InvoiceInsertStatement();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private async void InvoiceInsertStatement()
        {
            try
            {
                WinBO ObjPack_dt = new WinBO();
                ObjPack_dt.sqlquery = "select * from TBL_INVOICE where flag is null or flag='N'";
              //  ObjPack_dt.sqlquery = "select * from TBL_INVOICE";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjPack_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            ObjPack_dt.SALESID  = dt.Rows[i]["SN"].ToString();
                            ObjPack_dt.ITEMCODE = dt.Rows[i]["ITEMCODE"].ToString();
                            ObjPack_dt.SN = dt.Rows[i]["SN"].ToString();
                            ObjPack_dt.INVOICEDATE = Convert.ToDateTime(dt.Rows[i]["INVOICEDATE"].ToString());
                            ObjPack_dt.QTY = dt.Rows[i]["QTY"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["QTY"].ToString()) : 0.00;
                            ObjPack_dt.SRT = dt.Rows[i]["SRT"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["SRT"].ToString()) : 0.00;
                            ObjPack_dt.SVAL = dt.Rows[i]["SVAL"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["SVAL"].ToString()) : 0.00;
                            ObjPack_dt.IGSTPER = dt.Rows[i]["IGSTPER"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["IGSTPER"].ToString()) : 0.00;
                            ObjPack_dt.IGSTAMOUNT = dt.Rows[i]["IGSTAMOUNT"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["IGSTAMOUNT"].ToString()) : 0.00;
                            ObjPack_dt.CGSTPER = dt.Rows[i]["CGSTPER"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["CGSTPER"].ToString()) : 0.00;
                            ObjPack_dt.CGSTAMOUNT = dt.Rows[i]["CGSTAMOUNT"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["CGSTAMOUNT"].ToString()) : 0.00;
                            ObjPack_dt.SGSTPER = dt.Rows[i]["SGSTPER"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["SGSTPER"].ToString()) : 0.00;
                            ObjPack_dt.SGSTAMOUNT = dt.Rows[i]["SGSTAMOUNT"].ToString().Length > 0 ? Convert.ToDouble(dt.Rows[i]["SGSTAMOUNT"].ToString()) : 0.00;
                            ObjPack_dt.CUSID = dt.Rows[i]["CUSID"].ToString();
                            ObjPack_dt.DEST = dt.Rows[i]["DEST"].ToString();
                            ObjPack_dt.CSTATE = dt.Rows[i]["CSTATE"].ToString();
                            ObjPack_dt.LRNO = dt.Rows[i]["LRNO"].ToString();
                            //ObjPack_dt.LRDATE = Convert.ToDateTime(dt.Rows[i]["LRDATE"].ToString());
                            ObjPack_dt.LRDATE =  dt.Rows[i]["LRDATE"].ToString () == ""  ? DateTime .Today  : Convert .ToDateTime (dt.Rows[i]["LRDATE"].ToString());

                            ObjPack_dt.SITEID = dt.Rows[i]["SITEID"].ToString();
                            ObjPack_dt.RECID = Convert.ToInt64(dt.Rows[i]["RECID"].ToString());
                            
                            DataTable PackingIndx = new DataTable();
                            PackingIndx = WinBL.insertInvoicedt(ObjPack_dt);

                        }

                        string Invoice = "Insert Invoicedetails " + "_" + dt.Rows.Count;
                        string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                          "VALUES (now(),'" + Invoice + "' )";
                        string InsertQuery = WinBL.ExecuteNonq(sqlquery);
                    }
                    UpdateInvoiceStatement();
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void UpdateInvoiceStatement()
        {
            try
            {
                WinBO ObjDis_dt = new WinBO();
                ObjDis_dt.sqlquery = "update TBL_INVOICE set flag='Y' where flag is null or flag='N'";
                string url = "http://192.168.15.25/GNSA/GETQUERY";
                using (var client = new HttpClient())
                {
                    string json = JsonConvert.SerializeObject(ObjDis_dt);
                    var result = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
                    var data = result.Content.ReadAsStringAsync();
                    string Employeedts = Convert.ToString(data.Result.ToString().Trim());
                    var dt = JsonConvert.DeserializeObject<DataTable>(Employeedts);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    ds.Tables.Add(dt);
                    if (dt.Rows.Count > 0)
                    {

                    }
                    AutoEndTrancation();
                  
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void AutoEndTrancation()
        {
            try
            {

                WinBO ObjDis_dt = new WinBO();

                string sqlquery = "INSERT INTO bmb_trn_autotransaction(trn_date,trn_type)" +
                                  "VALUES (now(),'End Process')";

                string InsertQuery = WinBL.ExecuteNonq(sqlquery);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
