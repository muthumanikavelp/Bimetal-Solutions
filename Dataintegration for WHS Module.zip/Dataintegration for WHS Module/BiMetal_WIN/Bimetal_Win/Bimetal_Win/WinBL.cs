﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace Bimetal_Win
{
    public class WinBL
    {

        public static  string ExecuteNonq(string  ObjQuery)
        {
            string Query = "";
            try
            {
                GlobalODBC objInsertQuery = new GlobalODBC();
              Query = objInsertQuery.ExecuteNonQuery(ObjQuery);
                return Query;
            }
            catch(Exception ex)
            {
                return Query;
            }
        }

        public static DataTable insertDistributordt(WinBO ObjDis_dt)
        {
            DataTable tab = new DataTable();
            int i = 0;
            try
            {
                GlobalODBC objDistributor_dl = new GlobalODBC();
                tab = objDistributor_dl.InsertDistributorDetails(ObjDis_dt);
                return tab;
            }
            catch (Exception ex)
            {
                return tab;
            }
        }
        public static DataTable insertProductdt(WinBO ObjProd_dt)
        {
            DataTable tab = new DataTable();
            try
            {
                GlobalODBC objProductdetails_dl = new GlobalODBC();
                tab = objProductdetails_dl.InsertProductDetails(ObjProd_dt);
                return tab;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
                return tab;
            }
        }
        public static DataTable insertPackingdt(WinBO ObjPack_dt)
        {
            DataTable tab = new DataTable();
            try
            {
                GlobalODBC objPackingdetails_dl = new GlobalODBC();
                tab = objPackingdetails_dl.InsertPackingDetails(ObjPack_dt);
                return tab;
            }
            catch (Exception ex)
            {
                return tab;
            }
        }

        public static DataTable insertInvoicedt(WinBO ObjPack_dt)
        {
            DataTable tab = new DataTable();
            try
            {
                GlobalODBC objInvoicedetails_dl = new GlobalODBC();
                tab = objInvoicedetails_dl.InsertInvoiceDetails (ObjPack_dt);
                return tab;
            }
            catch (Exception ex)
            {
                return tab;
            }
        }

    }
}
