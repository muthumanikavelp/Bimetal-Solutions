﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bimetal_Win
{
   public  class WinBO
    {
        public string CUSTOMERCODE { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string COUNTRY { get; set; }
        public string CSTATE { get; set; }
        public string CITY { get; set; }
        public string PINCODE { get; set; }
        public string CONTACTPERSON { get; set; }
        public string MOBILENO { get; set; }
        public string EMAIL { get; set; }
        public string CADDRESS { get; set; }
        public string GSTNO { get; set; }
        public string LOCATION { get; set; }
        public Int64 RECID { get; set; }
        public string sqlquery { get; set; }

        public string ITEMCODE { get; set; }
        public string ITEMGROUP { get; set; }
        public string PRODUCTDESC { get; set; }
        public double MRP { get; set; }
        public string MODELNO { get; set; }
        public string SIZE { get; set; }
        public double PIECES { get; set; }
        public double LISTPRICE { get; set; }
        public string EngineType { get; set; }
        public double INCENAMNT { get; set; }
        public string PART_NO { get; set; }

        public string SN { get; set; }
        public DateTime INVOICEDATE { get; set; }
        public string DISTRIBUTOR_CODE { get; set; }
        public string PN { get; set; }
        public double QTY { get; set; }
        public string BOXNO { get; set; }
        public string TRANSPORT { get; set; }
        public string MK { get; set; }
        public string OENO { get; set; }

        public string SALESID { get; set; }
        public double SRT { get; set; }
        public double SVAL { get; set; }
        public double IGSTPER { get; set; }
        public double IGSTAMOUNT { get; set; }
        public double CGSTPER { get; set; }
        public double CGSTAMOUNT { get; set; }
        public double SGSTPER { get; set; }
        public double SGSTAMOUNT { get; set; }
        public string CUSID { get; set; }
        public string DEST { get; set; }
        
        public string LRNO { get; set; }
        public DateTime LRDATE { get; set; }
        public string SITEID { get; set; }
    }
    public class query
    {
        public string sqlquery { get; set; }
    }
    
}
