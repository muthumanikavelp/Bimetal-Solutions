﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities
{
    public class subtosubcategory
    {

        public int Subtosubcat_id { get; set; }

        public int Subcat_id { get; set; }

        public string Subtosubcat_Name { get; set; }

    }
}
